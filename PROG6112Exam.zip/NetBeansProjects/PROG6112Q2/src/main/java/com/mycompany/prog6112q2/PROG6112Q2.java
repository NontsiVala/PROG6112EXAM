/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog6112q2;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
/**
 *
 * @author Student
 */
public class PROG6112Q2 {

    public static void main(String[] args) {
        public interface IProductCalculations{
        double GetVat();
        double GetCommission();
        double GetTotal();        
        }
        
    public class ProductCalculations implements IProductCalculations {
        private double price;
        
        public productCalculations(double price) {
        this.price = price;
        }
        
        @Override
        public double GetVat(){
        return price * 0.15;
        }
        
        @Override
        public double GetCommision(){
        return price * 0.05;
        }
        
        @Override
        public double GetTotal(){
        return price + GetVat() + GetCommission();
        }
    }
    
    }
public class ProductApp extends JFrame{
        private JTextField txtCustomerName;
}

}
