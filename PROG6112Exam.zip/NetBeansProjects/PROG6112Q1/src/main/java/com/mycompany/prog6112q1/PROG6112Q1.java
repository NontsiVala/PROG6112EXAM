/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog6112q1;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class PROG6112Q1 {

    public interface IProduct  {
        int GetTotalProductsSold();
        double GetAverageProductsSold();
        String GetMostPopularProduct();
    }
    
public class Product implements IProduct {
    private String[] products;
    private int[][] sales;
    
    public Product(String[] products, int[][]
   sales) {
    this.products = products;
    this.sales = sales;
    }

@Override
public int GetTotalProductsSold(){
    int total = 0;
    for (int i = 0; i<sales.length;i++) {
        for (int j = 0; j < sales[i].length;j++){
            total += sales[i][j];
     }
 }
 return total;
}

@Override
public double GetAverageProductSold() {
    int total = GetTotalProductsSold();
    int count = sales.length*sales[0].length;
    return (double)total/count;
}

@Override
public String GetMostPopularProduct() {
    int maxSale = sales[0][0];
    String mostPopular = products[0];
    
    for (int i=0;i<sales.length;i++){
        for (int j=0;j<sales[i].length;j++){
            if (sales[i][j]>maxSale){
                maxSale = sales[i][j];
                mostPopular = products[i];
            }
        } 
    }
    return mostPopular + "("+maxSale + 
  ")";
}
}

public class PrintProduct {
  private Product product;
  
  public PrintProduct(Product product){
      this.product = product;
  }
  
  public void printTotalSales(){
      System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
  }
  
  public void printAverageSales(){
      System.out.printf("AVERAGE PRODUCT SALES: %.0f%n", product.GetAverageProductSold());
  }
  
  public void printMostPopular() {
      System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
  }
  
  public void printReport() {
  System.out.println("\nPRODUCT SALES REPORT - 2026");
  
  System.out.println("****************************");
  printTotalSales();
  printAverageSales();
  printMostPopularProduct();
  
  scanner.close();
  }
}


public class Main {
    public static void main (String[] args) {
        Scanner scanner = new
            Scanner(System.in);
        
        String[] products = {
        "Cozy  Nights Monarh mattress",
        "Restonic Barbados mattress",
        "Sealy Phuket mattress"
        };
        
        int[][] sales = new int[3][3];
        
        for (int i=0;i< products.length;i++){
            for (int j=0;j<3;j++){
            System.out.print("Enter number of sales for month " +(j+1)+"for"+ products[i]+":");
                sales[i][j] = scanner.nextInt();
            }
        System.out.println();
        }
    Product productData = new
  Product(shortNames,sales);
    PrintProduct printer = new
  PrintProduct(productData);
       print.printReport();
       
       scanner.close();
    
    }
}

}
